# Rudov Vladislav 931801
